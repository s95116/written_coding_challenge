var models  = require('../models');
var express = require('express');
var router  = express.Router();

router.post('/:person_id/tasks/create', function (req, res) {
  models.Task.create({
    task: req.body.task,
    person_id: req.params.person_id
  }).then(function() {
    res.redirect('/');
  });
});

// router.destroy = function ( req, res ){
//   models.Task( req.body.task, function (task ){
//     task.remove( function (task ){
//       res.redirect( '/' );
//     });
//   });
// };

// router.delete('/:person_id/tasks/delete'), function(req, res) {
//   models.Task.destroy({
//     task: req.body.task
//   }).then(function(){
//     res.redirect('/')
//   });
// };

router.delete('/delete/:id', function(req,res) {

  models.Task.destroy({
    where: {
      id: req.params.id && task.id === req.body.session.user_id
    }
  })
  // connect it to this .then.
  .then(function() {
    res.redirect('/');
  });

});

module.exports = router;
